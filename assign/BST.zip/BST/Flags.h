// Comment to test individual method
#define ALL 1

// Uncomment to test individual method
//#define CONSTRUCTOR 1
//#define DESTRUCTOR 1
//#define ISEMPTY 1
//#define FIND 1
//#define FINDMIN 1
//#define FINDMAX 1
//#define INSERT 1
//#define REMOVE 1
//#define MAKEEMPTY 1

//#define FINDNODE 1
//#define FINDMINNODE 1
//#define FINDMAXNODE 1
//#define FINDSUCCESSOR 1
//#define FINDPARENTOF 1
//#define INSERTNODE 1
//#define REMOVEALLNODES 1

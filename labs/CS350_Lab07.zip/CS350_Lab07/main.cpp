#include <iostream>
#include <cstdlib>
#include <cassert>
#include <ctime>

class Node {
public:
    Node *left, *right;
    int key;

    Node(int k) : left(NULL), right(NULL), key(k) { }
    ~Node() { }

    // create a random BST containing keys in given range
    static Node *makeRandomBST(int min, int max);

    // do an in-order traversal to print the keys in order
    void printKeysInOrder() const;

    // Find the node with the given search key:
    // returns NULL if no such node exists.
    Node *find(int searchVal);
};

Node *Node::makeRandomBST(int min, int max)
{
    // Base case
    if (min == max) {
        return new Node(min);
    }

    // Adjust min and max to narrow the range.
    // This will leave gaps in the range of keys.
    // (If we don't do this, the BST will contain every
    // key between min and max inclusive.)
    int r = (max-min);
    int x = 0;
    while (r/2 > 0) {
        r /= 2;
        x++;
    }
    if (min + x < max - x) {
        min += x;
        max -= x;
    }

    int mid = min + (rand() % (max-min+1));
    assert(mid >= min);
    assert(mid <= max);

    Node *n = new Node(mid);
    if (mid > min) {
        n->left = makeRandomBST(min, mid-1);
    }
    if (mid < max) {
        n->right = makeRandomBST(mid+1, max);
    }

    return n;
}

void Node::printKeysInOrder() const
{
    // TODO
}

Node *Node::find(int searchKey)
{
    // TODO
    return NULL;
}

int main(void) {
    srand(time(NULL));

    Node *root = Node::makeRandomBST(1, 50);

    std::cout << "The BST contains the following keys:" << std::endl;
    root->printKeysInOrder();
    std::cout << std::endl;

    bool done = false;
    while (!done) {
        std::cout << "Enter a key to search for (-1 to quit): ";
        int searchKey;
        std::cin >> searchKey;
    
        if (searchKey < 0) {
            done = true;
        } else {
            Node *result = root->find(searchKey);
            if (result == NULL) {
                std::cout << "Not found" << std::endl;
            } else {
                std::cout << "Found!" << std::endl;
            }
        }
    }

    return 0;
}
